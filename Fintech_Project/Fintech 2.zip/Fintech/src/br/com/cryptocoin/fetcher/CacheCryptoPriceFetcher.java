package br.com.cryptocoin.fetcher;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.concurrent.ConcurrentHashMap;

public class CacheCryptoPriceFetcher {
//
//    private static final ConcurrentHashMap<String, Double> cachePrice = new ConcurrentHashMap<>();
//    private static LocalDateTime lastPriceFetcher = LocalDateTime.MIN;
//
//    public static double getCachedPrice(String crypto, String cash, int cacheDuration){
//        LocalDateTime now = LocalDateTime.now();
//
//        if(cachePrice.containsKey())
//
//    }


}
