package br.com.cryptocoin.wallet;

public class Deposit extends Account{
}
