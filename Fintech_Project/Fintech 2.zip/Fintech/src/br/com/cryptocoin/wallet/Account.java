package br.com.cryptocoin.wallet;

public class Account {
}
