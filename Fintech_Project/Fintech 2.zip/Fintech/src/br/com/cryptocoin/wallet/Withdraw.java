package br.com.cryptocoin.wallet;

public class Withdraw extends Account{
}
