package br.com.cryptocoin.coins.model;

import br.com.cryptocoin.fetcher.CryptoPriceFetcher;

public class Crypto {

//pares de moedas
    public String getUsd() {
        return "usd";}

    public String getBrl() {
        return "brl";}

    //crypto
    public String getBitcoin() {
        return "bitcoin";}

    public String getSolana() {
        return "solana";
    }

    public String getUsdt() {
        return "tether";
    }

    public String getDog() {
        return "doge";
    }
}

