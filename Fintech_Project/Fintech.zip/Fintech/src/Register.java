public class Register {

    UserInfoRegister userInfo;

    public void loginValida(UserInfoRegister userInfo){
        //valida os dados para registrar no banco de dados
    }

}
