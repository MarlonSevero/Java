public class Login {

    //realiza a acao de validar se existe os dados do usuario no banco de dados
}
